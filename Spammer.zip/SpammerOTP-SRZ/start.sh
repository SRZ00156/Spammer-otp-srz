#!/bin/bash

# Colors
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
NC='\033[0m'

echo -e "${GREEN}"
echo "╔════════════════════════════════════════╗"
echo "║          WA OTP SPAMMER PRO           ║"
echo "║              SORANZX EDITION          ║"
echo "╚════════════════════════════════════════╝"
echo -e "${NC}"

# Check if in correct directory
if [ -f "main.py" ]; then
    python main.py
else
    echo -e "${RED}[!] Error: File main.py tidak ditemukan!${NC}"
    echo -e "${YELLOW}[!] Pastikan Anda berada di directory yang benar${NC}"
    echo -e "${BLUE}[!] Gunakan: cd Spammer-otp-srz${NC}"
fi