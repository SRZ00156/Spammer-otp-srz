#!/bin/bash

# Colors
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
PURPLE='\033[1;35m'
CYAN='\033[1;36m'
NC='\033[0m'

show_banner() {
    clear
    echo -e "${PURPLE}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║                   🚀 WA OTP SPAMMER 🚀                      ║"
    echo "║                 🔥 OFFICIAL INSTALLER 🔥                   ║"
    echo "║                                                              ║"
    echo "║    ███████╗███████╗██████╗ ██╗   ██╗███████╗██████╗         ║"
    echo "║    ██╔════╝██╔════╝██╔══██╗██║   ██║██╔════╝██╔══██╗        ║"
    echo "║    ███████╗█████╗  ██████╔╝██║   ██║█████╗  ██████╔╝        ║"
    echo "║    ╚════██║██╔══╝  ██╔══██╗╚██╗ ██╔╝██╔══╝  ██╔══██╗        ║"
    echo "║    ███████║███████╗██║  ██║ ╚████╔╝ ███████╗██║  ██║        ║"
    echo "║    ╚══════╝╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝        ║"
    echo "║                                                              ║"
    echo "║                   CREATED BY: SORANZX                        ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

check_system_requirements() {
    echo -e "${CYAN}[*] Checking system requirements...${NC}"
    
    local missing_packages=()
    
    if ! command -v python &> /dev/null; then
        missing_packages+=("python")
    fi
    
    if ! command -v pip &> /dev/null; then
        missing_packages+=("python-pip")
    fi
    
    if ! command -v git &> /dev/null; then
        missing_packages+=("git")
    fi
    
    if [ ${#missing_packages[@]} -ne 0 ]; then
        echo -e "${RED}[!] Missing system packages: ${missing_packages[*]}${NC}"
        echo -e "${YELLOW}"
        echo "Please run these commands first:"
        echo "apt update && apt upgrade -y"
        echo "pkg install bash curl wget jq -y"
        echo "pkg install python python-pip -y"
        echo "pkg install make clang -y"
        echo "pkg install git -y"
        echo -e "${NC}"
        exit 1
    fi
    
    echo -e "${GREEN}[+] System requirements satisfied!${NC}"
}

install_python_deps() {
    echo -e "${CYAN}[*] Installing Python dependencies...${NC}"
    
    if pip install -r requirements.txt; then
        echo -e "${GREEN}[+] Python dependencies installed!${NC}"
    else
        echo -e "${RED}[!] Failed to install Python dependencies${NC}"
        echo -e "${YELLOW}[!] Trying manual installation...${NC}"
        pip install requests colorama
    fi
}

setup_scripts() {
    echo -e "${CYAN}[*] Setting up scripts...${NC}"
    
    chmod +x start.sh installer.sh
    
    echo -e "${GREEN}[+] Scripts setup completed!${NC}"
}

show_instructions() {
    echo -e "${GREEN}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║                   🎉 INSTALLATION COMPLETE! 🎉             ║"
    echo "╠══════════════════════════════════════════════════════════════╣"
    echo "║                                                              ║"
    echo "║  📋 NEXT STEPS:                                             ║"
    echo "║                                                              ║"
    echo "║  1. Run the script:                                         ║"
    echo "║     ${YELLOW}python main.py${GREEN}                                       ║"
    echo "║     ${YELLOW}./start.sh${GREEN}                                           ║"
    echo "║     ${YELLOW}make run${GREEN}                                             ║"
    echo "║                                                              ║"
    echo "║  2. Use this token for login:                               ║"
    echo "║     ${YELLOW}wz6kLgwlKdLBhFwMgZ9bo6DKEq18Dk7vikqkG72So5U8pNVol${GREEN}   ║"
    echo "║                                                              ║"
    echo "║  3. For updates:                                            ║"
    echo "║     ${YELLOW}git pull${GREEN}                                             ║"
    echo "║     ${YELLOW}make update${GREEN}                                          ║"
    echo "║                                                              ║"
    echo "║  📢 REMEMBER: Only for educational purposes!                ║"
    echo "║                                                              ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

main() {
    show_banner
    check_system_requirements
    install_python_deps
    setup_scripts
    show_instructions
}

main